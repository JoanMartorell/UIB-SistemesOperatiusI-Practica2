Nombres de los autores:
1. Oriol Arderiu Canal
2. Joan Català Mas
3. Joan Martorell Coll

Mejoras:
Hemos implementado el cd avanzado



